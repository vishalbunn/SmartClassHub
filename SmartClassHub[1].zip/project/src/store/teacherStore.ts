import create from 'zustand';

interface TeacherStore {
  showLogoutConfirm: boolean;
  setShowLogoutConfirm: (show: boolean) => void;
  students: Student[];
  addStudent: (student: Student) => void;
  removeStudent: (id: string) => void;
  assignments: Assignment[];
  addAssignment: (assignment: Assignment) => void;
  updateAssignment: (id: string, assignment: Partial<Assignment>) => void;
}

interface Student {
  id: string;
  name: string;
  email: string;
  class: string;
}

interface Assignment {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  files: string[];
  assignedTo: string[];
  submissions: Submission[];
}

interface Submission {
  studentId: string;
  timestamp: string;
  status: 'submitted' | 'not_submitted' | 'late';
  files: string[];
  grade?: number;
  feedback?: string;
  latePenalty?: number;
}

const useStore = create<TeacherStore>((set) => ({
  showLogoutConfirm: false,
  setShowLogoutConfirm: (show) => set({ showLogoutConfirm: show }),
  
  students: [],
  addStudent: (student) =>
    set((state) => ({ students: [...state.students, student] })),
  removeStudent: (id) =>
    set((state) => ({
      students: state.students.filter((student) => student.id !== id),
    })),

  assignments: [],
  addAssignment: (assignment) =>
    set((state) => ({ assignments: [...state.assignments, assignment] })),
  updateAssignment: (id, updatedAssignment) =>
    set((state) => ({
      assignments: state.assignments.map((assignment) =>
        assignment.id === id
          ? { ...assignment, ...updatedAssignment }
          : assignment
      ),
    })),
}));

export default useStore;