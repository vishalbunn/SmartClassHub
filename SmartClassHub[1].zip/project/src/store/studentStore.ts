import create from 'zustand';

interface StudentStore {
  notes: Note[];
  addNote: (note: Note) => void;
  updateNote: (id: string, note: Partial<Note>) => void;
  deleteNote: (id: string) => void;
  assignments: Assignment[];
  updateAssignment: (id: string, status: AssignmentStatus) => void;
}

interface Note {
  id: string;
  title: string;
  content: string;
  tags: string[];
  color: string;
  courseId?: string;
  lastModified: string;
}

interface Assignment {
  id: string;
  title: string;
  courseId: string;
  dueDate: string;
  status: AssignmentStatus;
  grade?: string;
  feedback?: string;
}

type AssignmentStatus = 'pending' | 'submitted' | 'graded' | 'overdue';

const useStore = create<StudentStore>((set) => ({
  notes: [],
  addNote: (note) =>
    set((state) => ({ notes: [...state.notes, note] })),
  updateNote: (id, updatedNote) =>
    set((state) => ({
      notes: state.notes.map((note) =>
        note.id === id ? { ...note, ...updatedNote } : note
      ),
    })),
  deleteNote: (id) =>
    set((state) => ({
      notes: state.notes.filter((note) => note.id !== id),
    })),
  assignments: [],
  updateAssignment: (id, status) =>
    set((state) => ({
      assignments: state.assignments.map((assignment) =>
        assignment.id === id ? { ...assignment, status } : assignment
      ),
    })),
}));

export default useStore;