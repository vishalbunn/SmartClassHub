import React from 'react';
import { Save } from 'lucide-react';

interface NoteEditorProps {
  title: string;
  content: string;
  fileName: string;
  onTitleChange: (value: string) => void;
  onContentChange: (value: string) => void;
  onFileNameChange: (value: string) => void;
  onSave: () => void;
  onColorChange: (color: string) => void;
  colors: string[];
  selectedColor: string;
}

const NoteEditor: React.FC<NoteEditorProps> = ({
  title,
  content,
  fileName,
  onTitleChange,
  onContentChange,
  onFileNameChange,
  onSave,
  onColorChange,
  colors,
  selectedColor,
}) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="space-y-2 flex-1 mr-4">
          <input
            type="text"
            placeholder="Note Title"
            value={title}
            onChange={(e) => onTitleChange(e.target.value)}
            className="text-2xl font-bold bg-transparent border-none focus:outline-none w-full"
          />
          <input
            type="text"
            placeholder="File name (without .txt)"
            value={fileName}
            onChange={(e) => onFileNameChange(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-purple-500 focus:border-purple-500"
          />
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex space-x-1">
            {colors.map((color) => (
              <button
                key={color}
                onClick={() => onColorChange(color)}
                className={`w-6 h-6 rounded-full ${color} ${
                  selectedColor === color ? 'ring-2 ring-purple-600' : ''
                }`}
              />
            ))}
          </div>
          <button
            onClick={onSave}
            disabled={!title || !fileName}
            className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Save className="w-5 h-5" />
            <span>Save</span>
          </button>
        </div>
      </div>

      <textarea
        placeholder="Start typing your note..."
        value={content}
        onChange={(e) => onContentChange(e.target.value)}
        className="w-full h-[calc(100vh-300px)] p-4 bg-white rounded-lg shadow-sm border focus:ring-purple-500 focus:border-purple-500 resize-none"
      />
    </div>
  );
};

export default NoteEditor;