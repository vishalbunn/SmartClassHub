import React from 'react';

interface StatCardProps {
  label: string;
  value: string | number;
}

const StatCard: React.FC<StatCardProps> = ({ label, value }) => {
  return (
    <div className="p-4 bg-purple-50 rounded-lg">
      <h4 className="text-sm text-gray-600">{label}</h4>
      <p className="text-2xl font-bold text-purple-600">{value}</p>
    </div>
  );
};

export default StatCard;