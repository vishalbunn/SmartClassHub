import React, { useState } from 'react';
import { MessageSquare, AlertTriangle } from 'lucide-react';

interface AssignmentGradingProps {
  studentId: string;
  assignmentId: string;
  submission: {
    files: string[];
    submittedAt: string;
    isLate: boolean;
  };
  onGradeSubmit: (data: any) => void;
}

const AssignmentGrading: React.FC<AssignmentGradingProps> = ({
  studentId,
  assignmentId,
  submission,
  onGradeSubmit,
}) => {
  const [grade, setGrade] = useState('');
  const [feedback, setFeedback] = useState('');
  const [penalty, setPenalty] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGradeSubmit({
      studentId,
      assignmentId,
      grade,
      feedback,
      penalty,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">Submission Details</h3>
          <span className="text-sm text-gray-500">
            Submitted: {new Date(submission.submittedAt).toLocaleString()}
          </span>
        </div>

        {submission.isLate && (
          <div className="flex items-center space-x-2 text-yellow-600 mb-4">
            <AlertTriangle className="w-5 h-5" />
            <span className="text-sm">Late submission</span>
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Grade</label>
            <input
              type="number"
              min="0"
              max="100"
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
              placeholder="Enter grade (0-100)"
            />
          </div>

          {submission.isLate && (
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Late Submission Penalty (%)
              </label>
              <input
                type="number"
                min="0"
                max="100"
                value={penalty}
                onChange={(e) => setPenalty(Number(e.target.value))}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Feedback
            </label>
            <div className="mt-1 relative">
              <textarea
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                rows={4}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500"
                placeholder="Provide detailed feedback..."
              />
              <div className="absolute right-2 bottom-2">
                <MessageSquare className="w-5 h-5 text-gray-400" />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-700">Submitted Files</h4>
            <div className="space-y-2">
              {submission.files.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-2 bg-gray-50 rounded-md"
                >
                  <span className="text-sm text-gray-600">{file}</span>
                  <button
                    type="button"
                    className="text-purple-600 hover:text-purple-700 text-sm font-medium"
                  >
                    Download
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end space-x-3">
        <button
          type="button"
          className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          Save Draft
        </button>
        <button
          type="submit"
          className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700"
        >
          Submit Grade
        </button>
      </div>
    </form>
  );
};

export default AssignmentGrading;