import React from 'react';
import { PenTool, Download, Trash2 } from 'lucide-react';
import { Note } from '../store/noteStore';

interface NoteSidebarProps {
  notes: Note[];
  selectedTags: string[];
  onTagSelect: (tag: string) => void;
  onCreateNote: () => void;
  onOpenNote: (note: Note) => void;
  onDownloadNote: (note: Note) => void;
  onDeleteNote: (id: string) => void;
}

const NoteSidebar: React.FC<NoteSidebarProps> = ({
  notes,
  selectedTags,
  onTagSelect,
  onCreateNote,
  onOpenNote,
  onDownloadNote,
  onDeleteNote,
}) => {
  const availableTags = ['Math', 'Science', 'History', 'Important'];

  return (
    <div className="w-64 bg-white shadow-sm p-4 space-y-4">
      <button
        onClick={onCreateNote}
        className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
      >
        <PenTool className="w-5 h-5" />
        <span>New Note</span>
      </button>

      <div className="space-y-2">
        <h3 className="font-medium text-gray-700">Tags</h3>
        <div className="flex flex-wrap gap-2">
          {availableTags.map((tag) => (
            <button
              key={tag}
              onClick={() => onTagSelect(tag)}
              className={`px-2 py-1 rounded-full text-sm ${
                selectedTags.includes(tag)
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-100 text-gray-600'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="font-medium text-gray-700">Saved Notes</h3>
        <div className="space-y-2">
          {notes.map((note) => (
            <div
              key={note.id}
              className={`p-2 rounded-lg ${note.color} cursor-pointer`}
              onClick={() => onOpenNote(note)}
            >
              <div className="flex items-center justify-between mb-1">
                <h4 className="font-medium truncate">{note.title}</h4>
                <div className="flex space-x-1">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDownloadNote(note);
                    }}
                    className="p-1 hover:bg-white rounded-full"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteNote(note.id);
                    }}
                    className="p-1 hover:bg-white rounded-full text-red-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <p className="text-sm text-gray-500 truncate">{note.fileName}</p>
              <p className="text-xs text-gray-500">
                {new Date(note.lastModified).toLocaleDateString()}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NoteSidebar;