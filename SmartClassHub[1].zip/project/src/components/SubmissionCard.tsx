import React from 'react';

interface SubmissionCardProps {
  student: string;
  assignment: string;
  score: string;
}

const SubmissionCard: React.FC<SubmissionCardProps> = ({ student, assignment, score }) => {
  return (
    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
      <div>
        <h4 className="font-medium">{student}</h4>
        <p className="text-sm text-gray-500">{assignment}</p>
      </div>
      <span className="px-3 py-1 text-xs font-medium rounded-full bg-green-100 text-green-600">
        {score}
      </span>
    </div>
  );
};

export default SubmissionCard;