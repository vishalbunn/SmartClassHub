import React from 'react';

interface ProgressBarProps {
  name: string;
  progress: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ name, progress }) => {
  return (
    <div className="space-y-2">
      <div className="flex justify-between">
        <span className="text-sm font-medium">{name}</span>
        <span className="text-sm text-gray-500">{progress}%</span>
      </div>
      <div className="h-2 bg-gray-200 rounded-full">
        <div
          className="h-2 bg-purple-600 rounded-full transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;