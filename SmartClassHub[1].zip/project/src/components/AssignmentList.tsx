import React from 'react';
import { Clock, FileText, AlertTriangle } from 'lucide-react';

interface Assignment {
  id: string;
  title: string;
  dueDate: string;
  status: 'pending' | 'submitted' | 'late' | 'graded';
  grade?: string;
  feedback?: string;
}

interface AssignmentListProps {
  assignments: Assignment[];
  onAssignmentClick: (id: string) => void;
}

const AssignmentList: React.FC<AssignmentListProps> = ({ assignments, onAssignmentClick }) => {
  const getStatusColor = (status: Assignment['status']) => {
    switch (status) {
      case 'submitted':
        return 'bg-green-100 text-green-800';
      case 'late':
        return 'bg-red-100 text-red-800';
      case 'graded':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="space-y-4">
      {assignments.map((assignment) => (
        <div
          key={assignment.id}
          onClick={() => onAssignmentClick(assignment.id)}
          className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <FileText className="w-5 h-5 text-gray-400" />
              <div>
                <h3 className="text-lg font-medium text-gray-900">{assignment.title}</h3>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <Clock className="w-4 h-4" />
                  <span>Due: {new Date(assignment.dueDate).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <span
                className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(
                  assignment.status
                )}`}
              >
                {assignment.status}
              </span>
              {assignment.grade && (
                <span className="text-sm font-medium text-gray-900">{assignment.grade}</span>
              )}
            </div>
          </div>
          {assignment.feedback && (
            <div className="mt-2 text-sm text-gray-600">{assignment.feedback}</div>
          )}
          {assignment.status === 'late' && (
            <div className="mt-2 flex items-center text-sm text-red-600">
              <AlertTriangle className="w-4 h-4 mr-1" />
              Late submission penalty may apply
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default AssignmentList;