import React from 'react';
import { Routes, Route } from 'react-router-dom';
import {
  Book,
  Calendar,
  User,
  Settings,
  FileText,
  PenTool,
} from 'lucide-react';
import Sidebar from '../components/Sidebar';
import CoursesPage from './student/CoursesPage';
import SchedulePage from './student/SchedulePage';
import NotesPage from './student/NotesPage';
import ProfilePage from './student/ProfilePage';
import SettingsPage from './student/SettingsPage';
import AssignmentsPage from './student/AssignmentsPage';

const menuItems = [
  { icon: Book, label: 'My Courses', path: '/student/courses' },
  { icon: Calendar, label: 'Schedule', path: '/student/schedule' },
  { icon: FileText, label: 'Assignments', path: '/student/assignments' },
  { icon: PenTool, label: 'Notes', path: '/student/notes' },
  { icon: User, label: 'Profile', path: '/student/profile' },
  { icon: Settings, label: 'Settings', path: '/student/settings' },
];

const StudentDashboard: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar title="Smart Class Hub" menuItems={menuItems} />
        
        <div className="ml-64 flex-1 p-8">
          <Routes>
            <Route path="/courses/*" element={<CoursesPage />} />
            <Route path="/schedule" element={<SchedulePage />} />
            <Route path="/assignments" element={<AssignmentsPage />} />
            <Route path="/notes" element={<NotesPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;