import React from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import {
  Users,
  FileText,
  PieChart,
  User,
  Settings,
  LogOut,
} from 'lucide-react';
import Sidebar from '../components/Sidebar';
import StudentsPage from './teacher/StudentsPage';
import AssignmentsPage from './teacher/AssignmentsPage';
import AnalyticsPage from './teacher/AnalyticsPage';
import ProfilePage from './teacher/ProfilePage';
import SettingsPage from './teacher/SettingsPage';

const menuItems = [
  { icon: Users, label: 'Students', path: '/teacher/students' },
  { icon: FileText, label: 'Assignments', path: '/teacher/assignments' },
  { icon: PieChart, label: 'Analytics', path: '/teacher/analytics' },
  { icon: User, label: 'Profile', path: '/teacher/profile' },
  { icon: Settings, label: 'Settings', path: '/teacher/settings' },
];

const TeacherDashboard: React.FC = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out?')) {
      // Perform logout logic here
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <Sidebar 
          title="Smart Class Hub" 
          menuItems={menuItems} 
          onLogout={handleLogout}
        />

        <div className="ml-64 flex-1 p-8">
          <Routes>
            <Route path="/students" element={<StudentsPage />} />
            <Route path="/assignments" element={<AssignmentsPage />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;