import React, { useState, useRef } from 'react';
import { FileText } from 'lucide-react';
import useNoteStore, { Note } from '../../store/noteStore';
import NoteEditor from '../../components/NoteEditor';
import NoteSidebar from '../../components/NoteSidebar';

const NotesPage: React.FC = () => {
  const { notes, addNote, updateNote, deleteNote } = useNoteStore();
  const [activeNote, setActiveNote] = useState<Note | null>(null);
  const [showNewNote, setShowNewNote] = useState(false);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [fileName, setFileName] = useState('');
  const downloadRef = useRef<HTMLAnchorElement>(null);

  const colors = [
    'bg-red-100',
    'bg-yellow-100',
    'bg-green-100',
    'bg-blue-100',
    'bg-purple-100',
  ];

  const createNewNote = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      title: '',
      content: '',
      tags: [],
      color: colors[0],
      fileName: '',
      lastModified: new Date().toISOString(),
    };
    setActiveNote(newNote);
    setShowNewNote(true);
    setFileName('');
  };

  const handleSaveNote = () => {
    if (!activeNote?.title || !fileName) return;

    const noteToSave: Note = {
      ...activeNote,
      fileName: `${fileName}.txt`,
      lastModified: new Date().toISOString(),
    };

    if (notes.find(n => n.id === noteToSave.id)) {
      updateNote(noteToSave);
    } else {
      addNote(noteToSave);
    }

    setShowNewNote(false);
    setActiveNote(null);
    setFileName('');
  };

  const downloadNote = (note: Note) => {
    const blob = new Blob([note.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    if (downloadRef.current) {
      downloadRef.current.href = url;
      downloadRef.current.download = note.fileName;
      downloadRef.current.click();
    }
    
    URL.revokeObjectURL(url);
  };

  const handleTagSelect = (tag: string) => {
    setSelectedTags(prev =>
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  const openNote = (note: Note) => {
    setActiveNote(note);
    setShowNewNote(true);
    setFileName(note.fileName.replace('.txt', ''));
  };

  return (
    <div className="h-full flex">
      <a ref={downloadRef} className="hidden" />

      <NoteSidebar
        notes={notes}
        selectedTags={selectedTags}
        onTagSelect={handleTagSelect}
        onCreateNote={createNewNote}
        onOpenNote={openNote}
        onDownloadNote={downloadNote}
        onDeleteNote={deleteNote}
      />

      <div className="flex-1 p-6">
        {(showNewNote || activeNote) ? (
          <NoteEditor
            title={activeNote?.title || ''}
            content={activeNote?.content || ''}
            fileName={fileName}
            onTitleChange={(value) =>
              setActiveNote(prev => prev ? { ...prev, title: value } : null)
            }
            onContentChange={(value) =>
              setActiveNote(prev => prev ? { ...prev, content: value } : null)
            }
            onFileNameChange={setFileName}
            onSave={handleSaveNote}
            onColorChange={(color) =>
              setActiveNote(prev => prev ? { ...prev, color } : null)
            }
            colors={colors}
            selectedColor={activeNote?.color || colors[0]}
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-[calc(100vh-200px)]">
            <FileText className="w-16 h-16 text-gray-400 mb-4" />
            <p className="text-gray-500">
              Select a note or create a new one to get started
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default NotesPage;