import React from 'react';
import { Calendar, Clock, BookOpen } from 'lucide-react';

interface ScheduleEvent {
  id: string;
  title: string;
  course: string;
  startTime: string;
  endTime: string;
  type: 'class' | 'exam' | 'assignment';
  location?: string;
}

const SchedulePage: React.FC = () => {
  // Mock schedule data
  const schedule: Record<string, ScheduleEvent[]> = {
    Monday: [
      {
        id: '1',
        title: 'Mathematics 101',
        course: 'MATH101',
        startTime: '09:00',
        endTime: '10:30',
        type: 'class',
        location: 'Room 201',
      },
      {
        id: '2',
        title: 'Physics Lab',
        course: 'PHY102',
        startTime: '11:00',
        endTime: '12:30',
        type: 'class',
        location: 'Lab 3',
      },
    ],
    Tuesday: [
      {
        id: '3',
        title: 'Chemistry Quiz',
        course: 'CHEM101',
        startTime: '10:00',
        endTime: '11:00',
        type: 'exam',
        location: 'Room 305',
      },
    ],
    Wednesday: [
      {
        id: '4',
        title: 'Math Assignment Due',
        course: 'MATH101',
        startTime: '23:59',
        endTime: '23:59',
        type: 'assignment',
      },
    ],
    Thursday: [
      {
        id: '5',
        title: 'English Literature',
        course: 'ENG201',
        startTime: '14:00',
        endTime: '15:30',
        type: 'class',
        location: 'Room 102',
      },
    ],
    Friday: [
      {
        id: '6',
        title: 'Computer Science',
        course: 'CS101',
        startTime: '13:00',
        endTime: '14:30',
        type: 'class',
        location: 'Lab 1',
      },
    ],
  };

  const getEventTypeStyles = (type: ScheduleEvent['type']) => {
    switch (type) {
      case 'exam':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'assignment':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-purple-100 text-purple-800 border-purple-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Weekly Schedule</h1>
        <div className="flex items-center space-x-2 text-sm text-gray-500">
          <Calendar className="w-5 h-5" />
          <span>March 2024</span>
        </div>
      </div>

      <div className="grid grid-cols-5 gap-4">
        {Object.entries(schedule).map(([day, events]) => (
          <div key={day} className="space-y-4">
            <h2 className="font-medium text-gray-900">{day}</h2>
            <div className="space-y-2">
              {events.map((event) => (
                <div
                  key={event.id}
                  className={`p-3 rounded-lg border ${getEventTypeStyles(
                    event.type
                  )}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">{event.title}</h3>
                    <span className="text-xs px-2 py-1 rounded-full bg-white bg-opacity-50">
                      {event.type}
                    </span>
                  </div>
                  <div className="space-y-1 text-sm">
                    {event.type === 'assignment' ? (
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>Due {event.startTime}</span>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>
                            {event.startTime} - {event.endTime}
                          </span>
                        </div>
                        {event.location && (
                          <div className="flex items-center space-x-1">
                            <BookOpen className="w-4 h-4" />
                            <span>{event.location}</span>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-medium mb-4">Upcoming Events</h2>
        <div className="space-y-4">
          {Object.values(schedule)
            .flat()
            .slice(0, 3)
            .map((event) => (
              <div
                key={event.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      event.type === 'exam'
                        ? 'bg-red-500'
                        : event.type === 'assignment'
                        ? 'bg-yellow-500'
                        : 'bg-purple-500'
                    }`}
                  />
                  <div>
                    <h3 className="font-medium">{event.title}</h3>
                    <p className="text-sm text-gray-500">{event.course}</p>
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  {event.startTime} {event.type !== 'assignment' && `- ${event.endTime}`}
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default SchedulePage;