import React, { useState } from 'react';
import { UserCircle, Mail, Bell, Lock, Camera } from 'lucide-react';

const ProfilePage: React.FC = () => {
  // Mock student data
  const [student, setStudent] = useState({
    name: 'John Doe',
    email: 'john.doe@student.edu',
    studentId: 'STU123456',
    grade: '11th Grade',
    joinDate: '2023-09-01',
    courses: [
      { id: '1', name: 'Mathematics 101', instructor: 'Dr. Smith' },
      { id: '2', name: 'Physics', instructor: 'Prof. Johnson' },
      { id: '3', name: 'English Literature', instructor: 'Ms. Williams' },
    ],
  });

  const [notificationPreferences, setNotificationPreferences] = useState({
    assignmentReminders: true,
    gradeUpdates: true,
    courseAnnouncements: true,
    dailyDigest: false,
  });

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Profile Header */}
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="bg-purple-600 h-32"></div>
        <div className="px-8 pb-8">
          <div className="relative flex items-center">
            <div className="absolute -top-16">
              <div className="bg-white p-2 rounded-full">
                <UserCircle className="w-24 h-24 text-purple-600" />
                <button className="absolute bottom-0 right-0 p-2 bg-purple-600 text-white rounded-full hover:bg-purple-700">
                  <Camera className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="ml-36 pt-4">
              <h1 className="text-2xl font-bold">{student.name}</h1>
              <div className="flex items-center space-x-2 text-gray-600">
                <Mail className="w-4 h-4" />
                <span>{student.email}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-medium mb-4">Personal Information</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Student ID
              </label>
              <input
                type="text"
                value={student.studentId}
                readOnly
                className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Grade Level
              </label>
              <input
                type="text"
                value={student.grade}
                readOnly
                className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Join Date
              </label>
              <input
                type="text"
                value={new Date(student.joinDate).toLocaleDateString()}
                readOnly
                className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md"
              />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-medium mb-4">Notification Preferences</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Assignment Reminders</p>
                <p className="text-sm text-gray-500">
                  Get notified about upcoming assignments
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationPreferences.assignmentReminders}
                  onChange={(e) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      assignmentReminders: e.target.checked,
                    })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Grade Updates</p>
                <p className="text-sm text-gray-500">
                  Get notified when grades are posted
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationPreferences.gradeUpdates}
                  onChange={(e) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      gradeUpdates: e.target.checked,
                    })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Course Announcements</p>
                <p className="text-sm text-gray-500">
                  Get notified about course updates
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={notificationPreferences.courseAnnouncements}
                  onChange={(e) =>
                    setNotificationPreferences({
                      ...notificationPreferences,
                      courseAnnouncements: e.target.checked,
                    })
                  }
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Enrolled Courses */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-medium mb-4">Enrolled Courses</h2>
        <div className="space-y-4">
          {student.courses.map((course) => (
            <div
              key={course.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div>
                <h3 className="font-medium">{course.name}</h3>
                <p className="text-sm text-gray-500">
                  Instructor: {course.instructor}
                </p>
              </div>
              <button className="text-purple-600 hover:text-purple-700 font-medium">
                View Course
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Security Settings */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Lock className="w-5 h-5 text-purple-600" />
          <h2 className="text-lg font-medium">Security Settings</h2>
        </div>
        <div className="space-y-4">
          <button className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 rounded-lg hover:bg-gray-100">
            <span className="font-medium">Change Password</span>
            <Lock className="w-5 h-5" />
          </button>
          <button className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 rounded-lg hover:bg-gray-100">
            <span className="font-medium">Two-Factor Authentication</span>
            <Lock className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Save Changes Button */}
      <div className="flex justify-end">
        <button className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
          Save Changes
        </button>
      </div>
    </div>
  );
};

export default ProfilePage;