import React, { useState } from 'react';
import { Clock, AlertTriangle, CheckCircle, Bell } from 'lucide-react';

interface Assignment {
  id: string;
  title: string;
  course: string;
  dueDate: string;
  status: 'pending' | 'submitted' | 'graded' | 'overdue';
  grade?: string;
  feedback?: string;
}

const AssignmentsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('upcoming');

  // Mock data
  const assignments: Assignment[] = [
    {
      id: '1',
      title: 'Math Quiz - Algebra',
      course: 'Mathematics 101',
      dueDate: '2024-03-25T15:00:00',
      status: 'pending',
    },
    {
      id: '2',
      title: 'Science Lab Report',
      course: 'Physics',
      dueDate: '2024-03-20T23:59:59',
      status: 'graded',
      grade: '95%',
      feedback: 'Excellent work! Very thorough analysis.',
    },
  ];

  const getStatusColor = (status: Assignment['status']) => {
    switch (status) {
      case 'submitted':
        return 'bg-yellow-100 text-yellow-800';
      case 'graded':
        return 'bg-green-100 text-green-800';
      case 'overdue':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  const announcements = [
    {
      id: '1',
      title: 'Midterm Schedule Released',
      content: 'The midterm examination schedule has been posted.',
      date: '2024-03-19T10:00:00',
    },
    {
      id: '2',
      title: 'System Maintenance',
      content: 'The system will be under maintenance this weekend.',
      date: '2024-03-18T14:30:00',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Assignments & Updates</h1>
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'upcoming'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            Upcoming
          </button>
          <button
            onClick={() => setActiveTab('completed')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'completed'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            Completed
          </button>
          <button
            onClick={() => setActiveTab('announcements')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'announcements'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            Announcements
          </button>
        </div>
      </div>

      {(activeTab === 'upcoming' || activeTab === 'completed') && (
        <div className="space-y-4">
          {assignments
            .filter((assignment) =>
              activeTab === 'upcoming'
                ? ['pending', 'overdue'].includes(assignment.status)
                : ['submitted', 'graded'].includes(assignment.status)
            )
            .map((assignment) => (
              <div
                key={assignment.id}
                className="bg-white rounded-lg shadow-sm p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-medium">{assignment.title}</h3>
                    <p className="text-sm text-gray-500">{assignment.course}</p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(
                      assignment.status
                    )}`}
                  >
                    {assignment.status}
                  </span>
                </div>

                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>
                      Due: {new Date(assignment.dueDate).toLocaleString()}
                    </span>
                  </div>
                  {assignment.status === 'overdue' && (
                    <div className="flex items-center space-x-1 text-red-600">
                      <AlertTriangle className="w-4 h-4" />
                      <span>Overdue</span>
                    </div>
                  )}
                </div>

                {assignment.grade && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-medium">Grade: {assignment.grade}</span>
                    </div>
                    {assignment.feedback && (
                      <p className="text-gray-600">{assignment.feedback}</p>
                    )}
                  </div>
                )}

                <div className="mt-4 flex justify-end space-x-3">
                  <button className="px-4 py-2 text-purple-600 hover:bg-purple-50 rounded-lg">
                    View Details
                  </button>
                  {assignment.status === 'pending' && (
                    <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
                      Submit
                    </button>
                  )}
                </div>
              </div>
            ))}
        </div>
      )}

      {activeTab === 'announcements' && (
        <div className="space-y-4">
          {announcements.map((announcement) => (
            <div
              key={announcement.id}
              className="bg-white rounded-lg shadow-sm p-6"
            >
              <div className="flex items-center space-x-3 mb-4">
                <Bell className="w-6 h-6 text-purple-600" />
                <div>
                  <h3 className="font-medium">{announcement.title}</h3>
                  <p className="text-sm text-gray-500">
                    {new Date(announcement.date).toLocaleString()}
                  </p>
                </div>
              </div>
              <p className="text-gray-600">{announcement.content}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AssignmentsPage;