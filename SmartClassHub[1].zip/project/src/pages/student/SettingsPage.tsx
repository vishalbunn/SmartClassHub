import React, { useState } from 'react';
import { Bell, Lock, Moon, Eye, Monitor } from 'lucide-react';

const SettingsPage: React.FC = () => {
  const [notifications, setNotifications] = useState({
    email: true,
    browser: false,
    assignments: true,
    grades: true,
  });

  const [appearance, setAppearance] = useState('light');

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <h1 className="text-2xl font-bold">Settings</h1>

      {/* Notifications Settings */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Bell className="w-5 h-5 text-purple-600" />
          <h2 className="text-lg font-medium">Notifications</h2>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Email Notifications</p>
              <p className="text-sm text-gray-500">Receive updates via email</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notifications.email}
                onChange={(e) =>
                  setNotifications({ ...notifications, email: e.target.checked })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Browser Notifications</p>
              <p className="text-sm text-gray-500">Show desktop notifications</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notifications.browser}
                onChange={(e) =>
                  setNotifications({ ...notifications, browser: e.target.checked })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Assignment Updates</p>
              <p className="text-sm text-gray-500">
                Notifications for new assignments and due dates
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notifications.assignments}
                onChange={(e) =>
                  setNotifications({
                    ...notifications,
                    assignments: e.target.checked,
                  })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Grade Updates</p>
              <p className="text-sm text-gray-500">
                Notifications when grades are posted
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notifications.grades}
                onChange={(e) =>
                  setNotifications({ ...notifications, grades: e.target.checked })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Appearance Settings */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Monitor className="w-5 h-5 text-purple-600" />
          <h2 className="text-lg font-medium">Appearance</h2>
        </div>
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <button
              onClick={() => setAppearance('light')}
              className={`p-4 rounded-lg border-2 ${
                appearance === 'light'
                  ? 'border-purple-600'
                  : 'border-gray-200'
              }`}
            >
              <div className="flex items-center justify-center space-x-2">
                <Eye className="w-5 h-5" />
                <span>Light</span>
              </div>
            </button>
            <button
              onClick={() => setAppearance('dark')}
              className={`p-4 rounded-lg border-2 ${
                appearance === 'dark'
                  ? 'border-purple-600'
                  : 'border-gray-200'
              }`}
            >
              <div className="flex items-center justify-center space-x-2">
                <Moon className="w-5 h-5" />
                <span>Dark</span>
              </div>
            </button>
            <button
              onClick={() => setAppearance('system')}
              className={`p-4 rounded-lg border-2 ${
                appearance === 'system'
                  ? 'border-purple-600'
                  : 'border-gray-200'
              }`}
            >
              <div className="flex items-center justify-center space-x-2">
                <Monitor className="w-5 h-5" />
                <span>System</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Lock className="w-5 h-5 text-purple-600" />
          <h2 className="text-lg font-medium">Security</h2>
        </div>
        <div className="space-y-4">
          <button className="w-full flex items-center justify-between px-4 py-2 bg-gray-50 rounded-lg hover:bg-gray-100">
            <span className="font-medium">Change Password</span>
            <Lock className="w-5 h-5" />
          </button>
          <button className="w-full flex items-center justify-between px-4 py-2 bg-gray-50 rounded-lg hover:bg-gray-100">
            <span className="font-medium">Two-Factor Authentication</span>
            <Lock className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
          Save Changes
        </button>
      </div>
    </div>
  );
};

export default SettingsPage;