import React, { useState } from 'react';
import { Book, Bell, Clock, FileText } from 'lucide-react';

interface Course {
  id: string;
  name: string;
  instructor: string;
  pendingAssignments: number;
  materials: Material[];
  announcements: Announcement[];
}

interface Material {
  id: string;
  title: string;
  type: 'pdf' | 'video' | 'document';
  url: string;
}

interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
}

const CoursesPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('courses');
  
  // Mock data
  const courses: Course[] = [
    {
      id: '1',
      name: 'Mathematics 101',
      instructor: 'Dr. Smith',
      pendingAssignments: 2,
      materials: [
        { id: '1', title: 'Algebra Basics', type: 'pdf', url: '#' },
        { id: '2', title: 'Calculus Introduction', type: 'video', url: '#' },
      ],
      announcements: [
        {
          id: '1',
          title: 'Quiz Next Week',
          content: 'Prepare for Chapter 3 quiz next Tuesday',
          date: '2024-03-20',
        },
      ],
    },
    // Add more courses...
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">My Courses</h1>
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveTab('courses')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'courses'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            Courses
          </button>
          <button
            onClick={() => setActiveTab('materials')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'materials'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            Materials
          </button>
          <button
            onClick={() => setActiveTab('announcements')}
            className={`px-4 py-2 rounded-lg ${
              activeTab === 'announcements'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-100 text-gray-600'
            }`}
          >
            Announcements
          </button>
        </div>
      </div>

      {activeTab === 'courses' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <div
              key={course.id}
              className="bg-white rounded-lg shadow-sm p-6 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Book className="w-6 h-6 text-purple-600" />
                  <h3 className="text-lg font-medium">{course.name}</h3>
                </div>
                {course.pendingAssignments > 0 && (
                  <span className="px-2 py-1 text-xs font-medium bg-red-100 text-red-600 rounded-full">
                    {course.pendingAssignments} pending
                  </span>
                )}
              </div>
              <p className="text-sm text-gray-500">
                Instructor: {course.instructor}
              </p>
              <div className="flex justify-between">
                <button className="text-purple-600 hover:text-purple-700 text-sm font-medium">
                  View Details
                </button>
                <button className="text-purple-600 hover:text-purple-700 text-sm font-medium">
                  Join Class
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'materials' && (
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="space-y-4">
            {courses.map((course) => (
              <div key={course.id}>
                <h3 className="text-lg font-medium mb-2">{course.name}</h3>
                <div className="space-y-2">
                  {course.materials.map((material) => (
                    <div
                      key={material.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <FileText className="w-5 h-5 text-gray-400" />
                        <span>{material.title}</span>
                      </div>
                      <button className="text-purple-600 hover:text-purple-700 text-sm font-medium">
                        Download
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'announcements' && (
        <div className="space-y-4">
          {courses.flatMap((course) =>
            course.announcements.map((announcement) => (
              <div
                key={announcement.id}
                className="bg-white rounded-lg shadow-sm p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <Bell className="w-5 h-5 text-purple-600" />
                    <div>
                      <h3 className="font-medium">{announcement.title}</h3>
                      <p className="text-sm text-gray-500">{course.name}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <Clock className="w-4 h-4" />
                    <span>
                      {new Date(announcement.date).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <p className="text-gray-600">{announcement.content}</p>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default CoursesPage;