import React, { useState } from 'react';
import { Plus, Filter, Download, Eye } from 'lucide-react';
import useStore from '../../store/teacherStore';

const AssignmentsPage: React.FC = () => {
  const { assignments, addAssignment, updateAssignment, students } = useStore();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showSubmissionModal, setShowSubmissionModal] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterStudent, setFilterStudent] = useState('all');

  const handleCreateAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const newAssignment = {
      id: Date.now().toString(),
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      dueDate: formData.get('dueDate') as string,
      files: [],
      assignedTo: formData.getAll('assignedTo') as string[],
      submissions: [],
    };

    addAssignment(newAssignment);
    setShowCreateModal(false);
  };

  const handleGradeSubmission = (
    assignmentId: string,
    studentId: string,
    grade: number,
    feedback: string,
    latePenalty?: number
  ) => {
    updateAssignment(assignmentId, {
      submissions: assignments
        .find((a) => a.id === assignmentId)
        ?.submissions.map((s) =>
          s.studentId === studentId
            ? { ...s, grade, feedback, latePenalty }
            : s
        ),
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Assignments</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
        >
          <Plus className="w-5 h-5" />
          <span>Create Assignment</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex space-x-4 bg-white p-4 rounded-lg shadow">
        <div className="flex items-center space-x-2">
          <Filter className="w-5 h-5 text-gray-400" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="form-select border-gray-300 rounded-md"
          >
            <option value="all">All Status</option>
            <option value="submitted">Submitted</option>
            <option value="not_submitted">Not Submitted</option>
            <option value="late">Late</option>
          </select>
        </div>
        <select
          value={filterStudent}
          onChange={(e) => setFilterStudent(e.target.value)}
          className="form-select border-gray-300 rounded-md"
        >
          <option value="all">All Students</option>
          {students.map((student) => (
            <option key={student.id} value={student.id}>
              {student.name}
            </option>
          ))}
        </select>
      </div>

      {/* Assignments List */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Title
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Due Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Submissions
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {assignments.map((assignment) => (
              <tr key={assignment.id}>
                <td className="px-6 py-4">{assignment.title}</td>
                <td className="px-6 py-4">
                  {new Date(assignment.dueDate).toLocaleDateString()}
                </td>
                <td className="px-6 py-4">
                  {assignment.submissions.length} /{' '}
                  {assignment.assignedTo.length}
                </td>
                <td className="px-6 py-4 space-x-2">
                  <button
                    onClick={() => {
                      setSelectedAssignment(assignment.id);
                      setShowSubmissionModal(true);
                    }}
                    className="text-purple-600 hover:text-purple-900"
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                  <button className="text-gray-600 hover:text-gray-900">
                    <Download className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Create Assignment Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
            <h3 className="text-lg font-medium mb-4">Create New Assignment</h3>
            <form onSubmit={handleCreateAssignment} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Title
                </label>
                <input
                  type="text"
                  name="title"
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Description
                </label>
                <textarea
                  name="description"
                  required
                  rows={4}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Due Date
                </label>
                <input
                  type="datetime-local"
                  name="dueDate"
                  required
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Assign To
                </label>
                <div className="mt-2 space-y-2">
                  {students.map((student) => (
                    <label key={student.id} className="flex items-center">
                      <input
                        type="checkbox"
                        name="assignedTo"
                        value={student.id}
                        className="rounded border-gray-300 text-purple-600"
                      />
                      <span className="ml-2">{student.name}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
                >
                  Create Assignment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Submissions Modal */}
      {showSubmissionModal && selectedAssignment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full mx-4">
            <h3 className="text-lg font-medium mb-4">Assignment Submissions</h3>
            {/* Add submission details and grading interface here */}
            <button
              onClick={() => setShowSubmissionModal(false)}
              className="mt-4 px-4 py-2 bg-gray-200 rounded-lg"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AssignmentsPage;