import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import { Calendar, Users, BookOpen } from 'lucide-react';

const AnalyticsPage: React.FC = () => {
  // Mock data with proper number formatting
  const weeklyData = [
    { week: 'Week 1', submissions: 85, attendance: 95, avgScore: 88 },
    { week: 'Week 2', submissions: 78, attendance: 92, avgScore: 85 },
    { week: 'Week 3', submissions: 90, attendance: 88, avgScore: 92 },
    { week: 'Week 4', submissions: 95, attendance: 94, avgScore: 89 },
  ];

  const subjectPerformance = [
    { subject: 'Math', score: 85 },
    { subject: 'Science', score: 78 },
    { subject: 'History', score: 92 },
    { subject: 'English', score: 88 },
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 rounded-lg shadow-md border">
          <p className="font-medium">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {`${entry.name}: ${entry.value.toFixed(1)}%`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3">
            <Users className="w-8 h-8 text-purple-600" />
            <div>
              <p className="text-sm text-gray-500">Total Students</p>
              <p className="text-2xl font-bold">156</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3">
            <BookOpen className="w-8 h-8 text-purple-600" />
            <div>
              <p className="text-sm text-gray-500">Average Score</p>
              <p className="text-2xl font-bold">88.5%</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center space-x-3">
            <Calendar className="w-8 h-8 text-purple-600" />
            <div>
              <p className="text-sm text-gray-500">Attendance Rate</p>
              <p className="text-2xl font-bold">92.3%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Performance Chart */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-lg font-medium mb-6">Weekly Performance Overview</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis domain={[0, 100]} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line
                type="monotone"
                dataKey="submissions"
                stroke="#8b5cf6"
                name="Submissions"
                strokeWidth={2}
              />
              <Line
                type="monotone"
                dataKey="attendance"
                stroke="#10b981"
                name="Attendance"
                strokeWidth={2}
              />
              <Line
                type="monotone"
                dataKey="avgScore"
                stroke="#f59e0b"
                name="Average Score"
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Subject Performance Chart */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-lg font-medium mb-6">Subject Performance</h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={subjectPerformance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="subject" />
              <YAxis domain={[0, 100]} />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="score"
                fill="#8b5cf6"
                name="Score"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Weekly Summary */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-lg font-medium mb-4">Weekly Summary</h2>
        <div className="space-y-4">
          {weeklyData.map((week, index) => (
            <div
              key={index}
              className="p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium">{week.week}</h3>
                <span className="text-sm text-gray-500">
                  Average Score: {week.avgScore}%
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Submissions</p>
                  <p className="font-medium">{week.submissions}%</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Attendance</p>
                  <p className="font-medium">{week.attendance}%</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;