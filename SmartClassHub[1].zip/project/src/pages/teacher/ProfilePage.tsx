import React from 'react';
import { UserCircle, Mail, BookOpen, Calendar } from 'lucide-react';

const ProfilePage: React.FC = () => {
  // Mock teacher data
  const teacher = {
    name: 'Sarah Johnson',
    email: 'sarah.johnson@school.edu',
    department: 'Mathematics',
    joinDate: '2020-09-01',
    classes: [
      { id: '1', name: 'Mathematics 101', students: 25 },
      { id: '2', name: 'Advanced Algebra', students: 20 },
      { id: '3', name: 'Calculus', students: 15 },
    ],
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="bg-purple-600 h-32"></div>
        <div className="px-8 pb-8">
          <div className="relative flex items-center">
            <div className="absolute -top-16">
              <div className="bg-white p-2 rounded-full">
                <UserCircle className="w-24 h-24 text-purple-600" />
              </div>
            </div>
            <div className="ml-36 pt-4">
              <h1 className="text-2xl font-bold">{teacher.name}</h1>
              <div className="flex items-center space-x-2 text-gray-600">
                <Mail className="w-4 h-4" />
                <span>{teacher.email}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-medium mb-4">Personal Information</h2>
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">Department</p>
                <p className="font-medium">{teacher.department}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">Joined</p>
                <p className="font-medium">
                  {new Date(teacher.joinDate).toLocaleDateString()}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-medium mb-4">Assigned Classes</h2>
          <div className="space-y-4">
            {teacher.classes.map((cls) => (
              <div
                key={cls.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <div>
                  <h3 className="font-medium">{cls.name}</h3>
                  <p className="text-sm text-gray-500">
                    {cls.students} Students
                  </p>
                </div>
                <button className="text-purple-600 hover:text-purple-700 text-sm font-medium">
                  View Class
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-medium mb-4">Teaching Schedule</h2>
        <div className="grid grid-cols-5 gap-4">
          {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day) => (
            <div key={day} className="space-y-2">
              <h3 className="font-medium text-gray-700">{day}</h3>
              <div className="space-y-2">
                <div className="p-2 bg-purple-50 rounded text-sm">
                  <p className="font-medium">Mathematics 101</p>
                  <p className="text-gray-500">9:00 AM - 10:30 AM</p>
                </div>
                <div className="p-2 bg-purple-50 rounded text-sm">
                  <p className="font-medium">Advanced Algebra</p>
                  <p className="text-gray-500">1:00 PM - 2:30 PM</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;